from django.apps import AppConfig


class SubjectAppConfig(AppConfig):
    name = 'subject_app'
