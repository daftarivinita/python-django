from django.apps import AppConfig


class LogAndRegisterAppConfig(AppConfig):
    name = 'log_and_register_app'
