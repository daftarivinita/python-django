from django.apps import AppConfig


class DisplayTimeConfig(AppConfig):
    name = 'display_time'
