from django.apps import AppConfig


class AppforbooksandauthorsConfig(AppConfig):
    name = 'appforbooksandauthors'
